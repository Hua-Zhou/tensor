function M=uplus(M)
%Unary plus for KronProd class


