function out=anym(X)

out=full(any(X(:)));
