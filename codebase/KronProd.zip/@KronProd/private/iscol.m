function out=iscol(a)
%Returns true if A is a column vector.

if size(a,2)==1 & isvec(a)

out=1;

else

out=0;

end;





