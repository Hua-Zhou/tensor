function out=cp1(in)
% Outputs a matrix of ones the same size as IN


out=cp1s(in); %obsolete without the 's'