function out=allm(X)

out=full(all(X(:)));
