function cc=rowc(nn)
%Returns CC, an empty row cell array of length NN

cc= cell(1,nn);
