function out=isrow(a)

if size(a,1)==1 & isvec(a)

 out=1;

else

 out=0;

end;
