function sss=end(M,kk,nn)
%END method for KronProd

sss=length(M.opinds);
